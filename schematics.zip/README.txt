This is a text file incase you need help with installing schematica.
We have made a hypixel fourms guid on how to install and use schematica 
https://hypixel.net/threads/how-to-use-schematica-litematica-for-semi-afk-farms-context-below.4087613/

Thanks, Chance#0002